
const API_KEY = "lf-demo-2086";
const DATA_URL = "items.json";

const board = document.querySelector("#board");
const message = document.querySelector("#message");

// FIX 6: Added error handling for failed network requests.
// Found by checking what happens when the JSON request fails.
async function loadItems() {
  message.textContent = "Loading items...";

  try {
    const response = await fetch(DATA_URL + "?key=" + API_KEY);

    if (!response.ok) {
      throw new Error("Failed to load items: " + response.status);
    }

    // FIX 1: Added await because response.json() returns a Promise.
    // Found by inspecting the JSON parsing statement.
    const data = await response.json();

    render(data.results);
    message.textContent = "";

  } catch (error) {
    message.textContent = "Unable to load items. Please try again.";
    console.error("Error loading items:", error);
  }
}

function render(items) {
  board.innerHTML = items.map(item => `
    <div class="item ${item.claimed ? "claimed" : ""}">
      <!-- FIX 2: Changed item.label to item.name.
      Found by comparing app.js with the items.json property names. -->
      <h3>${escapeHTML(item.name)}</h3>

      <p>${escapeHTML(item.category)} · ${escapeHTML(item.place || "Unknown location")}</p>
      <p class="date">Found on ${escapeHTML(item.date)}</p>
    </div>
  `).join("");
}

// FIX 3: Added HTML escaping to prevent item data being interpreted as markup.
// Found by inspecting the HTML contained in item 7's name.
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

loadItems();
