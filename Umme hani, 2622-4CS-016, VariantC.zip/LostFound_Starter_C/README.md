# Lost & Found Board: Hand-over notes

**Name:**            **Roll No.:**            **Variant:** C

## 1. Fault log (Part 1)
| # | What I saw |
1) The items did not render correctly.
2) Item names appeared as undefined.
3) JavaScript could try to access HTML elements before they existed
4) Claimed items did not appear grey.
5) The item grid could overflow on smaller screens.

| # | What was wrong |
1)  response.json() was missing await, so the code tried to access results before the JSON had finished parsing.
2) JavaScript used item.label, but the JSON file uses item.name.
3)  The script was loaded in the HTML head without defer.
4) The #board .item selector overrode the .item.claimed styling.
5) The grid used three fixed 300px columns.
6) The fetch request had no try/catch error handling.

| # | how i found |
1)  I inspected the JavaScript and checked the Console for errors.
2) I compared the property names in app.js and items.json.
3) I inspected the script tag and its position in index.html.
4)  I inspected the CSS selectors and their specificity.
5)  I inspected the CSS and resized the browser window.
6)  I inspected the JavaScript and tested an unavailable JSON file.

-----------

## 2. What I built (Parts 2 to 4)
Error Handling testing ( PART 2)
Test a: Server Error (404)
Changed the DATA_URL from items.json to itemz.json.
so The server returned a 404 error because the file could not be found.
How I found it: Checked the Network tab in Chrome Developer Tools.
Test b: Network Failure
Changed DATA_URL to https://items.invalid/items.json. so The request failed because the address could not be reached.
found it when: checked the Console and Network tabs.
Final Check
Restored DATA_URL to items.json.
Reloaded the website and checked that all 14 items loaded correctly.

( PART 3)
Mobile Responsive Design

Updated the CSS to make the website responsive on mobile and desktop screens. Tested at 375px using Chrome DevTools Device Toolbar. Cards stack in one column on phones and use flexible columns on wider screens. Search and category controls have at least 44px height and readable text. Claimed items appear grey with a Claimed badge, while unclaimed items display a Still waiting badge.

(PART 4)
Change from the Client

Added a "Hide claimed items" checkbox to hide claimed items completely. Unclaimed items are displayed before claimed items. The checkbox works together with the search box and category dropdown, and the count updates correctly when filters are combined. Tested using the supplied JSON data.


## 3. AI log (at least 2 entries)
3. AI Log

Entry 1

I asked: Help me find and fix the errors in my JavaScript code.
The AI gave: Corrected JavaScript for loading JSON, searching, category filtering and error handling.
What was wrong or missing: Some suggested code needed adjustment to match the actual JSON data, especially the name property instead of label.
How I checked: Compared the code with items.json and tested the website using Chrome Console and Network tabs.

Entry 2

I asked: Help me make the website responsive and add the Hide claimed items feature.
The AI gave: Responsive CSS, status badges and JavaScript for hiding claimed items and sorting unclaimed items first.
What was wrong or missing: The checkbox also needed to be added to index.html, and the new filters needed to work with the existing search and category filters.
How I checked: Tested at 375px using Chrome DevTools and checked the checkbox, search, categories and count together.


4. One Thing I Would Improve Next

I would add an automatic expiry system that removes old lost-and-found listing after a certain number of days,so that keeping the board updated and making it easier for students to find recently reported items.