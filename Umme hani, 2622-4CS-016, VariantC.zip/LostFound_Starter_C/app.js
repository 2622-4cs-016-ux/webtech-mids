
const API_KEY = "lf-demo-2086";
const DATA_URL = "items.json";

const board = document.querySelector("#board");
const message = document.querySelector("#message");
const count = document.querySelector("#count");
const search = document.querySelector("#search");
const category = document.querySelector("#category");

// PART 4 - FIX 1: Connect the Hide claimed items checkbox.
const hideClaimed = document.querySelector("#hideClaimed");

let allItems = [];

// FIX 1: Added await because response.json() returns a Promise.
// Found by inspecting the JSON parsing statement.

// FIX 2: Added error handling for HTTP errors and network failures.
// Found by checking what happens when the data request fails.
async function loadItems() {
  message.textContent = "Loading items...";
  count.textContent = "";
  board.replaceChildren();

  try {
    const response = await fetch(DATA_URL + "?key=" + API_KEY);

    // Handle server errors such as 404 and 500.
    if (!response.ok) {
      throw new Error("SERVER_ERROR");
    }

    const data = await response.json();

    if (!Array.isArray(data.results)) {
      throw new Error("INVALID_DATA");
    }

    allItems = data.results;

    buildCategories();
    filterItems();

  } catch (error) {
    console.error("Loading error:", error);

    board.replaceChildren();
    count.textContent = "";

    if (error.message === "SERVER_ERROR") {
      message.textContent =
        "Sorry, the server could not find the items. Please check the file address.";
    } else if (error.message === "INVALID_DATA") {
      message.textContent =
        "Sorry, the items data is not in the expected format.";
    } else {
      message.textContent =
        "Unable to connect. Please check your internet connection and try again.";
    }
  }
}

// FIX 3: Categories are generated dynamically from JSON.
// Converted category names to lowercase to remove duplicates
// such as Keys and KEYS.
function buildCategories() {
  category.replaceChildren();

  const allOption = document.createElement("option");
  allOption.value = "all";
  allOption.textContent = "All categories";
  category.appendChild(allOption);

  const uniqueCategories = new Map();

  allItems.forEach(item => {
    if (item.category) {
      const originalName = String(item.category).trim();
      const key = originalName.toLowerCase();

      if (!uniqueCategories.has(key)) {
        uniqueCategories.set(key, originalName);
      }
    }
  });

  uniqueCategories.forEach((name, key) => {
    const option = document.createElement("option");
    option.value = key;
    option.textContent = name;
    category.appendChild(option);
  });
}

// FIX 4: Search is case-insensitive and works together
// with the selected category.
function filterItems() {
  const searchText = search.value.trim().toLowerCase();
  const selectedCategory = category.value.trim().toLowerCase();
  const shouldHideClaimed = hideClaimed.checked;

  const filteredItems = allItems.filter(item => {
    const itemName = String(item.name || "").toLowerCase();

    // FIX 5: Normalize both category values.
    // Keys and KEYS now match the same dropdown option.
    const itemCategory = String(item.category || "")
      .trim()
      .toLowerCase();

    const matchesSearch = itemName.includes(searchText);

    const matchesCategory =
      selectedCategory === "all" ||
      itemCategory === selectedCategory;

    // PART 4 - FIX 2: Hide claimed items when checkbox is selected.
    const matchesClaimed =
      !shouldHideClaimed || !item.claimed;

    return matchesSearch && matchesCategory && matchesClaimed;
  });

  // PART 4 - FIX 3: Show unclaimed items before claimed items.
  filteredItems.sort((a, b) =>
    Number(Boolean(a.claimed)) - Number(Boolean(b.claimed))
  );

  render(filteredItems);

  // FIX 6: Count updates after all filters are applied.
  count.textContent =
    `Showing ${filteredItems.length} of ${allItems.length}`;

  // FIX 7: Friendly message when no items match.
  if (filteredItems.length === 0) {
    message.textContent =
      "No items found. Try a different search or category.";
  } else {
    message.textContent = "";
  }
}

// FIX 8: Used textContent instead of innerHTML.
// This prevents HTML inside item names from changing the page.
function render(items) {
  board.replaceChildren();

  items.forEach(item => {
    const card = document.createElement("div");
    card.className = "item";

    if (item.claimed) {
      card.classList.add("claimed");
    }

    const heading = document.createElement("h3");
    heading.textContent = item.name ?? "";

    const details = document.createElement("p");
    details.textContent =
      `${item.category ?? "Other"} · ${item.place || "Place not recorded"}`;

    const date = document.createElement("p");
    date.className = "date";
    date.textContent = `Found on ${item.date ?? ""}`;

    // PART 3 - FIX 7: Added Claimed and Still waiting badges.
    const badge = document.createElement("span");

    badge.className = item.claimed
      ? "status-badge claimed-badge"
      : "status-badge waiting-badge";

    badge.textContent = item.claimed
      ? "Claimed"
      : "Still waiting";

    card.appendChild(heading);
    card.appendChild(details);
    card.appendChild(date);
    card.appendChild(badge);

    board.appendChild(card);
  });
}

// FIX 10: Search and category controls update results immediately.
search.addEventListener("input", filterItems);
category.addEventListener("change", filterItems);

// PART 4 - FIX 4: Update results when checkbox changes.
hideClaimed.addEventListener("change", filterItems);

// Start loading items.
loadItems();
